import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Parqueadero parqueadero = new Parqueadero();

        int opcion = 0;
        while (opcion != 8) {
            System.out.println("**** Bienvenido al Parqueadero ****");
            System.out.println("1. Ver los puestos disponibles del parqueadero");
            System.out.println("2. Ingresar un automovil al parqueadero");
            System.out.println("3. Dar salida a un automovil del parqueadero");
            System.out.println("4. Modificar la tarifa del parqueadero");
            System.out.println("5. Cambiar el tiempo del parqueadero");
            System.out.println("6. Avanzar el reloj del parqueadero");
            System.out.println("7. Mostrar ingresos del parqueadero");
            System.out.println("8. Salir");
            System.out.println("*********");
            System.out.print("Elija una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    int puestosDisponibles = parqueadero.calcularPuestosLibres();
                    System.out.println("La cantidad de puestos disponibles es: " + puestosDisponibles);
                    break;

                case 2:
                    System.out.print("Escriba la placa del automovil: ");
                    String placa = scanner.next();
                    int resultadoIngreso = parqueadero.entrarCarro(placa);
                    String mensajeIngreso = obtenerMensajeResultado(resultadoIngreso);
                    System.out.println(mensajeIngreso);
                    break;

                case 3:
                    System.out.print("Ingrese la placa del automovil para su salida: ");
                    String placaSalida = scanner.next();
                    int resultadoSalida = parqueadero.sacarCarro(placaSalida);
                    String mensajeSalida = obtenerMensajeResultado(resultadoSalida);
                    System.out.println(mensajeSalida);
                    break;

                case 4:
                    System.out.print("Ingrese la nueva tarifa: ");
                    int nuevaTarifa = scanner.nextInt();
                    parqueadero.cambiarTarifa(nuevaTarifa);
                    System.out.println("La tarifa del parqueadero se ha actualizado");
                    break;

                case 5:
                    System.out.print("Ingrese la nueva hora del parqueadero: ");
                    int avanzarHora = scanner.nextInt();
                    parqueadero.avanzarHora();
                    System.out.println("La hora del parqueadero ha actualizado");
                    break;

                case 6:
                    parqueadero.avanzarHora();
                    System.out.println("El reloj del parqueadero se ha adelantado");
                    break;

                case 7:
                    int ingresos = parqueadero.darMontoCaja();
                    System.out.println("Los ingresos del parqueadero son: " + ingresos);
                    break;

                case 8:
                    System.out.println("¡Gracias!");
                    break;

                default:
                    System.out.println("Opción inválida, escoja las opciones que se muestran en el menu");
                    break;
            }
            System.out.println();
        }
        scanner.close();
    }

    private static String obtenerMensajeResultado(int resultado) {
        switch (resultado) {
            case 1:
                return "El carro ha sido ingresado";
            case -1:
                return "No hay puestos disponibles";
            case -2:
                return "El carro ya se encuentra dentro del parqueadero";
            case -3:
                return "No existe un carro con la placa especificada en el parqueadero";
            default:
                return "Resultado desconocido";
        }
    }
}